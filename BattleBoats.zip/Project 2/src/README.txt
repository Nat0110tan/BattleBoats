Yilling Tan tan00250, Michael Ginzburg ginzb010

Yiling did the Cell Class and the BattleBoats class independently. Both Michael and YIlling worked on the Board and Game class together. Michael made Scanners for the Game class and worked on the fire method as well as the Board constructor in in Board.java. Yilling worked on the display, print, placeBoat Helper method, and most of the placeBoat method.

To compile program just do javac Game.java in terminal then to run the game you have to do java Game. After that you type in either 3, 6 , or 9 for the size board desired. They you start picking x and y cordinates(starting at 0) to see if you can gues where the ship is. When you guess all of the ships on the board the game ends and the amount of turns that it took you displays.

Assume that the player enters ints.

No additional features.

Bug is that sometimes the boats aren't the right size.

We have to place boats in the board, I have an idea of how to do that but I don’t know how to code it

 “I certify that the information contained in this README file is complete
and accurate. I have both read and followed the course policies in the ‘Academic Integrity - Course
Policy’ section of the course syllabus.”
Michael Ginzburg, Yilling Tan